/** @jsx jsx */
import { React, AllWidgetProps, jsx } from 'jimu-core'
import { IMConfig } from '../config'

import { MapViewManager } from 'jimu-arcgis'
import { Button } from 'jimu-ui'
import FeatureLayer from 'esri/layers/FeatureLayer'

export default class Widget extends React.PureComponent<
AllWidgetProps<IMConfig>,
any
> {
  constructor (props) {
    super(props)
    this.state = {}
  }

  readonly mvManager: MapViewManager = MapViewManager.getInstance()

  newLayers = [
    { url: 'https://services2.arcgis.com/PWJUSsdoJDp7SgLj/ArcGIS/rest/services/Utility_Map_Grid/FeatureServer/0', name: 'test1' },
    { url: 'https://services2.arcgis.com/PWJUSsdoJDp7SgLj/ArcGIS/rest/services/Infrastructure_Projects/FeatureServer/0', name: 'test2' }
  ]

  // ********** class lifecycle events ******************
  render () {
    return (
      <div>
        <h1>load data</h1>
        <Button onClick={() => { this.loadLayers() }}>add Layers</Button>
      </div>
    )
  }

  // ********** MY CUSTOM ******************
  loadLayers () {
    if (this.props) {
      const mapViewGroups = this.mvManager.getJimuMapViewGroup('widget_1')
      for (const id in mapViewGroups.jimuMapViews) {
        this.newLayers.forEach((layer) => {
          const featureLayer = new FeatureLayer({ url: layer.url })
          mapViewGroups.jimuMapViews[id].view.map.add(featureLayer)
        })
      }
    }
  }
}
