/** @jsx jsx */
import { React, AllWidgetProps, jsx } from 'jimu-core'
import { IMConfig } from '../config'

import { JimuMapView, MapViewManager } from 'jimu-arcgis'
import { Button } from 'jimu-ui'
import SceneView from 'esri/views/SceneView'

export default class Widget extends React.PureComponent<
AllWidgetProps<IMConfig>,
any
> {
  constructor (props) {
    super(props)
    this.state = { btnWeather: [] }
  }

  readonly mvManager: MapViewManager = MapViewManager.getInstance()

  // ********** class lifecycle events ******************
  componentDidMount (): void {
    this.setState({ btnWeather: this.renderButtons() })
  }

  componentDidUpdate (prevProps, prevState): void {
    if (this.props.config.weather.length !== prevProps.config.weather.length) {
      this.setState({ btnWeather: this.renderButtons() })
    }
  }

  render () {
    return (
      <div>
        <h1>Weather Widget</h1>
        {this.state.btnWeather}
      </div>
    )
  }

  // ********** MY CUSTOM ******************
  renderButtons () {
    const weatherType = []
    this.props.config.weather.forEach((w: string, i: number) => {
      weatherType.push(<Button key={i} onClick={() => { this.changeWeather(w) }}>{w}</Button>)
    })
    return weatherType
  }

  changeWeather (weather: string) {
    const map = this.getActiveMap()
    const view = map.view as SceneView
    view.environment.weather = {
      type: weather,
      cloudCover: 0.8,
      precipitation: 0.8
    }
  }

  getActiveMap (): JimuMapView {
    let returnVal = null
    if (this.props) {
      const mapViewGroups = this.mvManager.getJimuMapViewGroup('widget_1')
      for (const id in mapViewGroups.jimuMapViews) {
        returnVal = mapViewGroups.jimuMapViews[id]
      }
    }
    return returnVal
  }
}
