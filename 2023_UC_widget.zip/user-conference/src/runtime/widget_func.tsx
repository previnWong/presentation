/** @jsx jsx */
import { React, AllWidgetProps, jsx } from 'jimu-core'
import { JimuMapView, MapViewManager } from 'jimu-arcgis'
import { Button } from 'jimu-ui'
import { IMConfig } from '../config'
import SceneView from 'esri/views/SceneView'

import { useState, useEffect } from 'react'

const Widget = (props: AllWidgetProps<IMConfig>) => {
  const mvManager: MapViewManager = MapViewManager.getInstance()

  const [btnWeather, setButtons] = useState([])

  useEffect(() => {
    if (btnWeather.length !== props.config.weather.length) {
      renderButtons()
    }
  })

  return (
      <div>
        <h1>Weather Widget (Functional)</h1>
        {btnWeather}
      </div>
  )

  function renderButtons () {
    const weatherType = []
    props.config.weather.forEach((w: string, i: number) => {
      weatherType.push(<Button key={i} onClick={() => { changeWeather(w) }}>{w}</Button>)
    })
    setButtons(weatherType)
  }

  function changeWeather (weather: string) {
    const map = getActiveMap()
    const view = map.view as SceneView
    view.environment.weather = {
      type: weather,
      cloudCover: 0.8,
      precipitation: 0.8
    }
  }

  function getActiveMap (): JimuMapView {
    let returnVal = null
    if (props) {
      const mapViewGroups = mvManager.getJimuMapViewGroup('widget_1')
      for (const id in mapViewGroups.jimuMapViews) {
        returnVal = mapViewGroups.jimuMapViews[id]
      }
    }
    return returnVal
  }
}

export default Widget
