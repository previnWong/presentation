import { ImmutableObject } from 'seamless-immutable'

export interface Config {
  weather: string[]
}

export type IMConfig = ImmutableObject<Config>
