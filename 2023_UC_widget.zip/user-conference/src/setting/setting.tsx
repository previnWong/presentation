/** @jsx jsx */
import { jsx, React } from 'jimu-core'
import { BaseWidgetSetting, AllWidgetSettingProps } from 'jimu-for-builder'
import { IMConfig } from '../config'

import { Label, TextInput } from 'jimu-ui'
import { SettingSection, SettingRow } from 'jimu-ui/advanced/setting-components'

export default class Setting extends BaseWidgetSetting<
AllWidgetSettingProps<IMConfig>,
any
> {
  constructor (props) {
    super(props)
    this.state = {}
  }

  componentDidMount () {

  }

  render () {
    return (
      <div>
          <SettingSection
            title={'Weather Types'}
          >
            <TextInput
              onAcceptValue={(value) => {
                const existingWeather = [...this.props.config.weather]
                existingWeather.push(value)
                this.props.onSettingChange({
                  id: this.props.id,
                  config: this.props.config.set('weather', existingWeather)
                })
              }}
            />
            <h6>Existing Types</h6>
            {this.renderWeatherRows()}
          </SettingSection>
      </div>
    )
  }

  renderWeatherRows () {
    const weatherType = []
    this.props.config.weather.forEach((w: string, i: number) => {
      weatherType.push(
        <SettingRow>
          <Label>{w}</Label>
        </SettingRow>
      )
    })
    return (weatherType)
  }
}
